


<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- column -->
                    <div class="col-12">                                                
                        <div class="d-flex align-items-left">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('shipper-create')): ?>
                            <a class="btn btn-success d-none d-lg-block m-l-15"
                                href="<?php echo e(route('shippers.create')); ?>">Create New Shipment</a>
                            <?php endif; ?>
                        </div>
                        <div class="card">
                            <div class="card-body">
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>

                                <h4 class="card-title">Shippers/Shipping Agencies Table</h4>
                                <!-- <h6 class="card-subtitle">Add class <code>.table</code></h6> -->
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Company Name</th>
                                            <th>Contact Person</th>
                                            <th>Contact Number</th>
                                            <th>Address</th>
                                            <th width="280px">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $shippers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            <td><?php echo e($shipper->company_name); ?></td>
                                            <td><?php echo e($shipper->company_person); ?></td>
                                            <td><?php echo e($shipper->contact_number); ?></td>
                                            <td><?php echo e($shipper->address); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('shippers.destroy',$shipper->id)); ?>" method="POST">                    
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('shipper-edit')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('shippers.edit',$shipper->id)); ?>">Edit</a>
                                                    <?php endif; ?>


                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('shipper-delete')): ?>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                    <?php endif; ?>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php echo $shippers->links(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shipping-management-app\resources\views/shippers/index.blade.php ENDPATH**/ ?>