

<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- column -->
                    <div class="col-12">                                                
                        <div class="d-flex align-items-left">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('shipment-create')): ?>
                            <a class="btn btn-success d-none d-lg-block m-l-15"
                                href="<?php echo e(route('shipments.create')); ?>">Create New Shipment</a>
                            <?php endif; ?>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                
                                <h4 class="card-title">Shipments Table</h4>
                                <!-- <h6 class="card-subtitle">Add class <code>.table</code></h6> -->
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Shipper</th>
                                                <th>Client</th>
                                                <th>Shipping Line</th>
                                                <th>Agent</th>
                                                <th>origin</th>
                                                <th>destination</th>
                                                <th>Shipment Date</th>
                                                <th>Delivery Date</th>
                                                <th>Action</th>                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                <td>#</td>
                                                <td><?php echo e($shipment->shipper); ?></td>
                                                <td><?php echo e($shipment->company_name); ?></td>
                                                <td><?php echo e($shipment->name); ?></td>
                                                <td><?php echo e($shipment->agency_name); ?></td>
                                                <td><?php echo e($shipment->origin); ?></td>
                                                <td><?php echo e($shipment->destination); ?></td>
                                                <td><?php echo e($shipment->shipment_date); ?></td>
                                                <td><?php echo e($shipment->delivery_date); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('shipments.destroy',$shipment->id)); ?>" method="POST">                    
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('shipment-edit')): ?>
                                                        <a class="btn btn-primary" href="<?php echo e(route('shipments.edit',$shipment->id)); ?>">Edit</a>
                                                        <?php endif; ?>


                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('shipment-delete')): ?>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                        <?php endif; ?>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shipping-management-app\resources\views/shipments/index.blade.php ENDPATH**/ ?>